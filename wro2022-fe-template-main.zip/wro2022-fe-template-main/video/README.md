Video
====

This directory must contain the video.md file with a URL to YouTube (should be either public or accessible by link) showing the vehicle driving autonomously.
That part of the video where driving demonstration exists must be at least 30 seconds in length.
