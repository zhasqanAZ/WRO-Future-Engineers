Team's photos
====

This directory must contain 2 photos of the team (an official one and one funny photo with all team members)
